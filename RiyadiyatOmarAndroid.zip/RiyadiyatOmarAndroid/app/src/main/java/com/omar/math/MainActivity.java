package com.omar.math;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextToSpeech tts;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        tts = new TextToSpeech(this, status -> { if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("ar")); });
        WebView w = new WebView(this);
        WebSettings s = w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setBuiltInZoomControls(false); s.setTextZoom(100);
        w.addJavascriptInterface(new VoiceBridge(), "Android");
        w.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        w.loadUrl("file:///android_asset/index.html");
        setContentView(w);
    }
    public class VoiceBridge {
        @JavascriptInterface public void speak(String text) { runOnUiThread(() -> { if(tts!=null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "omar"); }); }
    }
    @Override protected void onDestroy(){ if(tts!=null){tts.stop();tts.shutdown();} super.onDestroy(); }
}
